package com.tour;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TourDBUtil {
		
	private static boolean isSuccess;
	private static Connection con = null;
	private static Statement stnt = null;
	private static ResultSet rs = null;
	
	//insert tours
	public static boolean inserttour(String tname, int days, int nights, int mno, String vehicle, String oname, String nic, String phone, String uname) {
		
		boolean isSuccess = false;
		
		try {
			con = DBConnect.getConnection();
			stnt = con.createStatement();
			
			String sql = "insert into tour values (0,'"+tname+"', '"+days+"', '"+nights+"', '"+mno+"', '"+vehicle+"', '"+oname+"', '"+nic+"', '"+phone+"', '"+uname+"')";
			int rs = stnt.executeUpdate(sql);
			
			if(rs > 0) {
				isSuccess = true;
			}else {
				isSuccess = false;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return isSuccess;
		
	}

	//validate the login
	public static boolean validate(String userName, String nic) {
		
		try {
			con = DBConnect.getConnection();
			stnt = con.createStatement();
			String sql = "select * from tour where org_username = '"+userName+"' and org_nic = '"+nic+"'";
			rs = stnt.executeQuery(sql);
			
			if ( rs.next()) {
				isSuccess = true;
			}else {
				isSuccess = false;
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess;
	}
	
	
	//get tour details by using the given username
	public static List<Tour> getTour(String userName){
		
		ArrayList<Tour> tour = new ArrayList<>();
		
		try {
			con = DBConnect.getConnection();
			stnt = con.createStatement();
			String sql = "select * from tour where org_username = '"+userName+"'";
			rs = stnt.executeQuery(sql);
			
			while(rs.next()) {
				int tid = rs.getInt(1);
				String tname = rs.getString(2);
				int days = rs.getInt(3);
				int nights = rs.getInt(4);
				int mno = rs.getInt(5);
				String vehicle = rs.getString(6);
				String name = rs.getString(7);
				String nic= rs.getString(8);
				String phone = rs.getString(9);
				String username= rs.getString(10);
				
				Tour tou = new Tour(tid, tname, days, nights, mno, vehicle, name, nic, phone, username);
				tour.add(tou);
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return tour;
		
		
		
	}

	//update the tour
	public static boolean updatetour( String tid, String tname, String days, String nights, String mno, String vehicle,
			String oname, String nic, String phone, String uname) {
		
		try {
			con = DBConnect.getConnection();
			stnt = con.createStatement();
			
			String sql = "update tour set tour_name = '"+tname+"', days = '"+days+"', nights= '"+nights+"', max_person= '"+mno+"',vehicle = '"+vehicle+"', org_name = '"+oname+"', org_nic = '"+nic+"', org_phone = '"+phone+"',  org_username= '"+uname+"'" + "where tour_id = '"+tid+"'";
			
			int rs = stnt.executeUpdate(sql);
			
			if(rs>0) {
				isSuccess = true;
			}
			else {
				isSuccess = false;
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	
		return isSuccess;
	}
	
	
	//retrieving
	
	public static List<Tour> getTourDetails(String Id){
		
		ArrayList<Tour> tour = new ArrayList<>();
		
		try {
			con = DBConnect.getConnection();
			stnt = con.createStatement();
			String sql = "select * from tour where tour_id= '"+Id+"' ";
			rs = stnt.executeQuery(sql);
			
			while(rs.next()) {
				int tid = rs.getInt(1);
				String tname = rs.getString(2);
				int days = rs.getInt(3);
				int nights = rs.getInt(4);
				int mno = rs.getInt(5);
				String vehicle = rs.getString(6);
				String name = rs.getString(7);
				String nic= rs.getString(8);
				String phone = rs.getString(9);
				String username= rs.getString(10);
				
				Tour tou = new Tour(tid, tname, days, nights, mno, vehicle, name, nic, phone, username);
				tour.add(tou);
			}
			
			
		}
		catch(Exception e){
			e.getStackTrace();
		}
		
		
		return tour;
		
	}
	
	
	//delete the tour
	public static boolean deleteTour(String tid) {
		
		
		try {
			
			con = DBConnect.getConnection();
			stnt = con.createStatement();
			String sql = "delete from tour where tour_id='"+tid+"'";
			int r = stnt.executeUpdate(sql);
			
			if(r > 0) {
				isSuccess = true;
				
			}
			else {
				isSuccess = false;
			}
			
			
		}
		catch (Exception e){
			e.printStackTrace();
		}
		
		
		return isSuccess;
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
