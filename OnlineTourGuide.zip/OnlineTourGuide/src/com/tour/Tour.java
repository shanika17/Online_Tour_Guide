package com.tour;

public class Tour {
	private int tid;
	private String tname;
	private int days;
	private int nights;
	private int mno;
	private String vehicle;
	private String oname;
	private String nic;
	private String phone;
	private String username;
	
	public Tour(int tid, String tname, int days, int nights, int mno, String vehicle, String oname, String nic,
			String phone, String username) {
		
		this.tid = tid;
		this.tname = tname;
		this.days = days;
		this.nights = nights;
		this.mno = mno;
		this.vehicle = vehicle;
		this.oname = oname;
		this.nic = nic;
		this.phone = phone;
		this.username = username;
	}

	public int getTid() {
		return tid;
	}

	
	public String getTname() {
		return tname;
	}

	
	public int getDays() {
		return days;
	}

	

	public int getNights() {
		return nights;
	}

	

	public int getMno() {
		return mno;
	}

	

	public String getVehicle() {
		return vehicle;
	}

	

	public String getOname() {
		return oname;
	}

	

	public String getNic() {
		return nic;
	}

	

	public String getPhone() {
		return phone;
	}

	

	public String getUsername() {
		return username;
	}

	
	
	

}
