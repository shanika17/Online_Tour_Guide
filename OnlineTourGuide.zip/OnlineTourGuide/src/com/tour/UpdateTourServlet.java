package com.tour;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/UpdateTourServlet")
public class UpdateTourServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String tid = request.getParameter("tid");
		String tname = request.getParameter("name");
		String days = request.getParameter("days");
		String nights = request.getParameter("nights");
		String mno = request.getParameter("mno");
		String vehicle = request.getParameter("vehicle");
		String oname = request.getParameter("oname");
		String nic = request.getParameter("nic");
		String phone = request.getParameter("phone");
		String uname = request.getParameter("uname");
		
		boolean isTrue;
		
		isTrue = TourDBUtil.updatetour(tid, tname, days, nights, mno, vehicle, oname, nic,phone,uname);
		
		if(isTrue == true) {
			
			List<Tour> tourDetails = TourDBUtil.getTourDetails(tid);
			request.setAttribute("tourDetails", tourDetails);
			
			RequestDispatcher dis= request.getRequestDispatcher("touraccount.jsp");
			dis.forward(request, response);
		} else {
			
			List<Tour> tourDetails = TourDBUtil.getTourDetails(tid);
			request.setAttribute("tourDetails", tourDetails);
			
			RequestDispatcher dis = request.getRequestDispatcher("touraccount.jsp");
			dis.forward(request, response);
		}
	}

}
