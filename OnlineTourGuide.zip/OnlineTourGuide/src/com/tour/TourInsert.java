package com.tour;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/TourInsert")
public class TourInsert extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String tname = request.getParameter("name");
		int days = Integer.parseInt(request.getParameter("days"));
		int nights = Integer.parseInt(request.getParameter("nights"));
		int mno = Integer.parseInt(request.getParameter("mno"));
		String vehicle = request.getParameter("vehicle");
		String oname = request.getParameter("oname");
		String nic = request.getParameter("nic");
		String phone = request.getParameter("phone");
		String uname = request.getParameter("uname");
		
		boolean isTrue;
		
		isTrue = TourDBUtil.inserttour(tname, days, nights, mno, vehicle, oname, nic, phone, uname);
		
		if(isTrue == true) {
			RequestDispatcher dis= request.getRequestDispatcher("success.jsp");
			dis.forward(request, response);
		} else {
			RequestDispatcher dis2 = request.getRequestDispatcher("unsuccess.jsp");
			dis2.forward(request, response);
		}
	}

}
